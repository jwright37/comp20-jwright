README for A5

This project was much harder than I expected. The subject material was not
difficult, but teaching myself all of the concepts and sorting out all of
the syntax without the help of TA's or Ming was tricky.

I did the simplist implication that I could. I did not know how to add 
styling and it wasnt included in the rubric, so I did not bother. All of 
the output is plain html. I spent a long time learning about Node, only to realize that express would handle most of the difficult parts of the serving
and routing. 

I had lots of problems with figuring out what different mongo functions return and what member functions are availible to them.